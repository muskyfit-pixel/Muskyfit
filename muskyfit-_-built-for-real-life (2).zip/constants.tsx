
import { FoodItem, Client, DailyLog } from './types';

export const FOOD_DATABASE: FoodItem[] = [
  { id: 'f1', name: 'Chapati (plain)', calories: 119, protein: 3, carbs: 20, fats: 3, type: 'INDIAN', servingSize: '1 chapati', suitableMeals: ['BREAKFAST', 'LUNCH', 'DINNER'], instructions: 'Heat a tawa, roll the dough thin, cook until puffed and lightly browned on both sides.' },
  { id: 'f2', name: 'Chapati (wholemeal)', calories: 131, protein: 4, carbs: 22, fats: 3, type: 'INDIAN', servingSize: '1 chapati', suitableMeals: ['BREAKFAST', 'LUNCH', 'DINNER'], instructions: 'Use wholewheat flour, knead with warm water, roll and cook on a hot dry pan.' },
  { id: 'f3', name: 'Chapati (with ghee)', calories: 155, protein: 3, carbs: 20, fats: 7, type: 'INDIAN', servingSize: '1 chapati', suitableMeals: ['BREAKFAST', 'LUNCH', 'DINNER'], instructions: 'Prepare a standard chapati and brush generously with melted ghee while hot.' },
  { id: 'f4', name: 'Roti (plain)', calories: 102, protein: 3, carbs: 18, fats: 2, type: 'INDIAN', servingSize: '1 chapati', suitableMeals: ['BREAKFAST', 'LUNCH', 'DINNER'] },
  { id: 'f16', name: 'Basmati rice (cooked)', calories: 225, protein: 4, carbs: 50, fats: 1, type: 'WESTERN', servingSize: '1 bowl (250g)', suitableMeals: ['LUNCH', 'DINNER'], instructions: 'Wash rice until water runs clear. Use 1:2 rice to water ratio. Simmer covered for 12 mins.' },
  { id: 'f32', name: 'Chicken breast (cooked)', calories: 185, protein: 35, carbs: 0, fats: 5, type: 'WESTERN', servingSize: '150g', suitableMeals: ['LUNCH', 'DINNER'], instructions: 'Season well. Grill or pan-sear for 6-8 mins per side until internal temp is 75°C.' },
  { id: 'f39', name: 'Eggs (whole)', calories: 146, protein: 12, carbs: 2, fats: 10, type: 'WESTERN', servingSize: '2 eggs', suitableMeals: ['BREAKFAST', 'SNACKS'], instructions: 'Boil for 6 mins (soft) or 9 mins (hard). Or scramble with a splash of milk.' },
  { id: 'f42', name: 'Paneer (regular)', calories: 276, protein: 18, carbs: 6, fats: 20, type: 'INDIAN', servingSize: '150g', suitableMeals: ['LUNCH', 'DINNER'], instructions: 'Cube and shallow fry or grill until edges are brown. Add to curries at the end.' },
  { id: 'f47', name: 'Broccoli', calories: 69, protein: 4, carbs: 11, fats: 1, type: 'WESTERN', servingSize: '200g bowl', suitableMeals: ['LUNCH', 'DINNER'], instructions: 'Steam for 4-5 mins to keep the crunch and nutrients. Avoid boiling.' },
  { id: 'f85', name: 'Whey shake', calories: 130, protein: 25, carbs: 3, fats: 2, type: 'DRINK', servingSize: '1 shake', suitableMeals: ['BREAKFAST', 'SNACKS'] },
  { id: 'pro1', name: 'Makhana (Roasted Fox Nuts)', calories: 110, protein: 3, carbs: 22, fats: 0, type: 'SNACKS', servingSize: '30g', suitableMeals: ['SNACKS'], instructions: 'Dry roast in a pan until crunchy. Optionally toss with a drop of ghee and pink salt.' },
];

/**
 * PRODUCTION READY: Mock clients removed.
 * App will initialize with empty state on first launch.
 */
export const MOCK_CLIENTS: Client[] = [];
