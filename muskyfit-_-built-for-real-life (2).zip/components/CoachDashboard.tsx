
import React, { useState } from 'react';
import { Client, DailyLog, ExerciseLog, WeeklyCheckIn } from '../types';
import { generatePerformanceReport } from '../services/geminiService';

interface CoachDashboardProps {
  clients: Client[];
  pendingClient: Client | null;
  onFinalise: (id: string, overrides: any) => void;
  isLoading: boolean;
}

const CoachDashboard: React.FC<CoachDashboardProps> = ({ clients, pendingClient, onFinalise, isLoading }) => {
  const [selectedClientId, setSelectedClientId] = useState<string | null>(null);
  const [editedFrequency, setEditedFrequency] = useState(pendingClient?.intake?.trainingDaysPerWeek || 3);
  const [generatedReport, setGeneratedReport] = useState<string | null>(null);
  const [isReporting, setIsReporting] = useState(false);

  const selectedClient = clients.find(c => c.id === selectedClientId);

  const handleResetSystem = () => {
    if (window.confirm("CRITICAL: This will delete ALL clients and logs from this device. Proceed?")) {
      localStorage.clear();
      window.location.reload();
    }
  };

  const handleGenerateReport = async () => {
    if (!selectedClient) return;
    setIsReporting(true);
    const mockCheckIn: WeeklyCheckIn = selectedClient.checkIns?.[0] || {
      date: new Date().toISOString(),
      energyLevel: 8,
      stressLevel: 4,
      sleepHours: 7,
      digestionStatus: 'Normal',
      clientComments: 'Solid week overall, feeling stronger in the gym.'
    };
    const report = await generatePerformanceReport(selectedClient.profile.name, selectedClient.logs, mockCheckIn);
    setGeneratedReport(report);
    
    if (selectedClient.checkIns?.length > 0) {
      selectedClient.checkIns[0].coachFeedback = report;
    }

    setIsReporting(false);
  };

  const calculateProgressionVelocity = (client: Client) => {
    const workoutLogs = client.logs.filter(l => l.workoutCompleted && l.exerciseLogs);
    if (workoutLogs.length < 2) return { status: 'AWAITING_DATA', velocity: 0 };
    
    const getVolume = (log: DailyLog) => (log.exerciseLogs || []).reduce((acc, ex) => 
      acc + ex.sets.reduce((sAcc, s) => sAcc + (s.weight * s.reps), 0), 0
    );

    const latestVolume = getVolume(workoutLogs[0]);
    const previousVolume = getVolume(workoutLogs[1]);
    const velocity = ((latestVolume - previousVolume) / (previousVolume || 1)) * 100;
    
    if (velocity > 2) return { status: 'ACCELERATING', velocity };
    if (velocity >= 0) return { status: 'STABLE', velocity };
    return { status: 'REGRESSING', velocity };
  };

  const getTrafficLight = (client: Client) => {
    if (!client.logs || client.logs.length === 0) return 'RED';
    const lastLog = client.logs[0];
    const targetCals = client.plan?.trainingDayMacros?.calories || 2500;
    const calorieVariance = Math.abs((lastLog.caloriesConsumed - targetCals) / targetCals);
    
    const energy = client.checkIns?.[0]?.energyLevel || 8;
    
    if (calorieVariance <= 0.08 && lastLog.steps >= 8000 && energy >= 7) return 'GREEN';
    if (calorieVariance <= 0.20 || lastLog.steps >= 5000) return 'AMBER';
    return 'RED';
  };

  return (
    <div className="space-y-12 pb-20 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row justify-between items-end gap-4 px-4 md:px-0">
        <div>
          <h2 className="text-5xl font-black text-white italic tracking-tighter uppercase leading-none">Command Center</h2>
          <p className="text-cyan-500 font-bold uppercase tracking-[0.4em] text-[10px] mt-2">Elite Progression Analysis</p>
        </div>
        <button onClick={handleResetSystem} className="text-[9px] font-black text-slate-700 hover:text-red-500 uppercase tracking-widest transition">
           Reset Local System
        </button>
      </div>

      {pendingClient && (
        <div className="bg-slate-900 border-2 border-cyan-900/30 rounded-[2.5rem] overflow-hidden shadow-2xl mx-4 md:mx-0">
          <div className="bg-cyan-950/20 px-10 py-8 border-b border-slate-800 flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex items-center gap-6">
               <div className="w-16 h-16 rounded-full bg-slate-950 border border-slate-800 overflow-hidden">
                 <img src={pendingClient.profile.avatar} className="w-full h-full object-cover" alt="" />
               </div>
               <div>
                  <h2 className="text-3xl font-black text-white">{pendingClient.profile.name}</h2>
                  <p className="text-cyan-500 font-black text-[10px] uppercase tracking-widest mt-1">Goal: {pendingClient.intake?.goal.replace('_', ' ')}</p>
               </div>
            </div>
            <button 
              onClick={() => onFinalise(pendingClient.id, { trainingDaysPerWeek: editedFrequency })}
              disabled={isLoading}
              className="px-12 py-5 bg-white text-black font-black uppercase tracking-[0.2em] rounded-2xl shadow-xl hover:bg-cyan-500 hover:text-white transition italic"
            >
              {isLoading ? 'ANALYSING...' : 'Publish 4-Week Block'}
            </button>
          </div>
        </div>
      )}

      <div className="grid lg:grid-cols-12 gap-10 px-4 md:px-0">
        <div className="lg:col-span-7 space-y-8">
          <div className="flex justify-between items-center">
            <h3 className="text-2xl font-black text-white uppercase tracking-tighter italic">Client Roster</h3>
            <span className="text-[10px] font-black text-slate-500 uppercase">{clients.length} Active</span>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            {clients.map(client => {
              const status = getTrafficLight(client);
              const velData = calculateProgressionVelocity(client);
              const isSelected = selectedClientId === client.id;
              const velColor = velData.status === 'ACCELERATING' ? 'text-green-400' : velData.status === 'STABLE' ? 'text-cyan-400' : 'text-red-400';

              return (
                <div key={client.id} onClick={() => { setSelectedClientId(client.id); setGeneratedReport(null); }} className={`bg-slate-900 p-8 rounded-[2.5rem] border ${isSelected ? 'border-cyan-500 ring-1 ring-cyan-500 shadow-[0_0_30px_rgba(6,182,212,0.2)]' : 'border-slate-800'} cursor-pointer hover:border-slate-700 transition-all group`}>
                  <div className="flex justify-between items-start mb-6">
                    <div className="flex gap-4 items-center">
                      <img src={client.profile.avatar} className="w-12 h-12 rounded-full border border-slate-700" alt="" />
                      <div>
                        <h4 className="text-xl font-black text-white">{client.profile.name}</h4>
                        <p className={`text-[9px] font-black uppercase tracking-widest italic ${velColor}`}>{velData.status}</p>
                      </div>
                    </div>
                    <div className={`w-3 h-3 rounded-full ${status === 'GREEN' ? 'bg-green-500' : status === 'AMBER' ? 'bg-amber-500' : 'bg-red-500'}`} />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                     <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-center">
                        <p className="text-[8px] font-black text-slate-500 uppercase mb-1">Adherence</p>
                        <p className="text-lg font-black text-white">{status === 'GREEN' ? 'ELITE' : status === 'AMBER' ? 'FAIR' : 'ACTION'}</p>
                     </div>
                     <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-center">
                        <p className="text-[8px] font-black text-slate-500 uppercase mb-1">Weekly Gain</p>
                        <p className={`text-lg font-black ${velColor}`}>{velData.velocity.toFixed(1)}%</p>
                     </div>
                  </div>
                </div>
              );
            })}
            {clients.length === 0 && (
              <div className="col-span-2 py-20 bg-slate-900/50 border-2 border-dashed border-slate-800 rounded-[2.5rem] text-center">
                 <p className="text-sm font-black text-slate-700 uppercase tracking-widest italic">No Active Clients Yet</p>
              </div>
            )}
          </div>
        </div>

        <div className="lg:col-span-5 space-y-8">
          <h3 className="text-2xl font-black text-white uppercase tracking-tighter italic">Intelligence Report</h3>
          {selectedClient ? (
            <div className="bg-slate-900 rounded-[3rem] p-10 border border-slate-800 shadow-2xl space-y-8 animate-in slide-in-from-right-4 duration-500">
              <div className="text-center">
                <h4 className="text-2xl font-black text-white italic">{selectedClient.profile.name}</h4>
                <p className="text-[10px] text-cyan-500 font-bold uppercase tracking-[0.3em] mt-1">Status Analysis</p>
              </div>

              {selectedClient.checkIns?.length > 0 && (
                <div className="p-6 bg-slate-950 rounded-2xl border border-slate-800 space-y-4">
                  <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Latest Check-In Comments</p>
                  <p className="text-xs text-slate-300 italic">"{selectedClient.checkIns[0].clientComments}"</p>
                  <div className="flex gap-4">
                    <span className="text-[10px] font-bold text-cyan-400">Energy: {selectedClient.checkIns[0].energyLevel}/10</span>
                    <span className="text-[10px] font-bold text-red-400">Stress: {selectedClient.checkIns[0].stressLevel}/10</span>
                  </div>
                </div>
              )}

              {generatedReport ? (
                <div className="bg-slate-950 p-8 rounded-3xl border border-cyan-500/20 shadow-inner">
                   <p className="text-[10px] font-black text-cyan-400 uppercase tracking-widest mb-4 italic">Performance Summary</p>
                   <div className="prose prose-invert prose-sm">
                      <p className="text-slate-300 text-sm leading-relaxed whitespace-pre-wrap">{generatedReport}</p>
                   </div>
                   <button onClick={() => setGeneratedReport(null)} className="mt-8 w-full py-4 bg-slate-900 text-slate-500 font-black uppercase tracking-widest text-[10px] rounded-xl hover:text-white transition">Reset Analysis</button>
                </div>
              ) : (
                <div className="space-y-6">
                   <div className="p-6 bg-slate-950 rounded-3xl border border-slate-800 text-center">
                      <p className="text-xs text-slate-500 italic mb-6">Review last 7 days of logs and subjective check-in data to generate professional feedback.</p>
                      <button 
                        onClick={handleGenerateReport}
                        disabled={isReporting}
                        className="w-full py-6 bg-cyan-600 text-white font-black uppercase tracking-[0.2em] rounded-2xl hover:bg-cyan-500 transition-all italic shadow-2xl disabled:opacity-50"
                      >
                        {isReporting ? 'GENERATING...' : 'Generate AI Report'}
                      </button>
                   </div>
                </div>
              )}
            </div>
          ) : (
            <div className="h-64 flex flex-col items-center justify-center bg-slate-900/30 rounded-[3rem] border-2 border-dashed border-slate-800 p-10 text-center text-slate-600">
               <p className="text-xs font-black uppercase tracking-widest leading-relaxed">Select a client from the roster to generate their weekly performance report</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CoachDashboard;
