
import React, { useState } from 'react';
import { WeeklyCheckIn } from '../types';

interface WeeklyCheckInFormProps {
  onSubmit: (checkIn: WeeklyCheckIn) => void;
}

const WeeklyCheckInForm: React.FC<WeeklyCheckInFormProps> = ({ onSubmit }) => {
  const [formData, setFormData] = useState<Omit<WeeklyCheckIn, 'date'>>({
    energyLevel: 7,
    stressLevel: 4,
    sleepHours: 7,
    digestionStatus: 'Good',
    clientComments: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      date: new Date().toISOString().split('T')[0]
    });
  };

  return (
    <div className="max-w-3xl mx-auto py-10 px-4 animate-in fade-in slide-in-from-bottom-6 duration-700">
      <div className="bg-slate-900 rounded-[3rem] p-10 border border-slate-800 shadow-2xl">
        <div className="text-center mb-10">
          <h2 className="text-4xl font-black text-white metallic-text italic uppercase">Weekly Reflection</h2>
          <p className="text-cyan-500 font-bold text-[10px] uppercase tracking-[0.4em] mt-2">Elite Feedback Loop</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-3">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-1">Energy Level (1-10)</label>
              <input 
                type="range" min="1" max="10" 
                value={formData.energyLevel} 
                onChange={e => setFormData({...formData, energyLevel: parseInt(e.target.value)})}
                className="w-full accent-cyan-500" 
              />
              <div className="flex justify-between text-[10px] font-bold text-slate-600 uppercase">
                <span>Low</span>
                <span className="text-cyan-400">{formData.energyLevel}</span>
                <span>Elite</span>
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-1">Avg Sleep (Hours)</label>
              <input 
                type="number" 
                value={formData.sleepHours} 
                onChange={e => setFormData({...formData, sleepHours: parseFloat(e.target.value)})}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl py-4 px-6 text-white focus:ring-1 focus:ring-cyan-500 outline-none" 
              />
            </div>

            <div className="space-y-3">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-1">Digestion</label>
              <select 
                value={formData.digestionStatus} 
                onChange={e => setFormData({...formData, digestionStatus: e.target.value})}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl py-4 px-6 text-white outline-none"
              >
                <option>Elite (Regular/No Bloat)</option>
                <option>Average (Occasional Bloat)</option>
                <option>Poor (Frequent Bloat/Pain)</option>
              </select>
            </div>

            <div className="space-y-3">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-1">Stress (1-10)</label>
              <input 
                type="range" min="1" max="10" 
                value={formData.stressLevel} 
                onChange={e => setFormData({...formData, stressLevel: parseInt(e.target.value)})}
                className="w-full accent-red-500" 
              />
              <div className="flex justify-between text-[10px] font-bold text-slate-600 uppercase">
                <span>Zen</span>
                <span className="text-red-400">{formData.stressLevel}</span>
                <span>Critical</span>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-1">Comments for MuskyFit Coach</label>
            <textarea 
              value={formData.clientComments} 
              onChange={e => setFormData({...formData, clientComments: e.target.value})}
              placeholder="How are you actually feeling? Any hunger? Gym wins?"
              className="w-full bg-slate-950 border border-slate-800 rounded-2xl py-4 px-6 text-white h-32 focus:ring-1 focus:ring-cyan-500 outline-none"
            />
          </div>

          <button 
            type="submit" 
            className="w-full py-6 bg-white text-black font-black uppercase tracking-[0.2em] rounded-2xl shadow-2xl hover:bg-cyan-500 hover:text-white transition-all italic"
          >
            Submit Weekly Check-In
          </button>
        </form>
      </div>
    </div>
  );
};

export default WeeklyCheckInForm;
