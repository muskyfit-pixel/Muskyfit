
import React from 'react';
import { DailyLog } from '../types';

interface ClientProgressSummaryProps {
  logs: DailyLog[];
}

const ClientProgressSummary: React.FC<ClientProgressSummaryProps> = ({ logs }) => {
  const recentLogs = [...logs].reverse().slice(-7);
  
  const maxSteps = Math.max(...recentLogs.map(l => l.steps), 10000);
  const chartHeight = 100;

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 p-8 rounded-[2.5rem] border border-slate-800 shadow-xl">
        <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-8 text-center italic">7-Day Step Adherence</h4>
        
        <div className="flex items-end justify-between gap-2 h-32 px-4">
          {recentLogs.map((log, i) => {
            const heightPercent = (log.steps / maxSteps) * 100;
            const isTargetHit = log.steps >= 10000;
            return (
              <div key={i} className="flex-1 flex flex-col items-center gap-2 group relative">
                <div className="absolute -top-8 bg-slate-950 px-2 py-1 rounded text-[8px] font-black text-white opacity-0 group-hover:opacity-100 transition shadow-xl border border-slate-800 pointer-events-none whitespace-nowrap z-10">
                  {log.steps.toLocaleString()}
                </div>
                <div 
                  className={`w-full rounded-t-lg transition-all duration-700 ${isTargetHit ? 'bg-cyan-500 cyan-glow shadow-[0_0_10px_rgba(6,182,212,0.5)]' : 'bg-slate-800'}`}
                  style={{ height: `${Math.max(heightPercent, 5)}%` }}
                />
                <span className="text-[8px] font-black text-slate-600 uppercase tracking-tighter">
                  {new Date(log.date).toLocaleDateString('en-GB', { weekday: 'short' })}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default ClientProgressSummary;
