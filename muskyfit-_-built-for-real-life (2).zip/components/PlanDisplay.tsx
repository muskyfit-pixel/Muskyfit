
import React, { useState } from 'react';
import { Meal, WorkoutDay, MacroSplit } from '../types';
import { getMealAlternatives } from '../services/geminiService';

interface PlanDisplayProps {
  mealPlan: Meal[];
  workoutSplit: WorkoutDay[];
  trainingDayMacros?: MacroSplit;
  restDayMacros?: MacroSplit;
  coachAdvice?: string;
}

const PlanDisplay: React.FC<PlanDisplayProps> = ({ mealPlan, workoutSplit, trainingDayMacros, restDayMacros, coachAdvice }) => {
  const [activeView, setActiveView] = useState<'MEALS' | 'EXERCISE' | 'ADVICE'>('MEALS');
  const [isTrainingDay, setIsTrainingDay] = useState(true);
  const [swappingMealIdx, setSwappingMealIdx] = useState<number | null>(null);
  const [alternatives, setAlternatives] = useState<string[]>([]);

  const handleSmartSwap = async (meal: Meal, idx: number) => {
    setSwappingMealIdx(idx);
    setAlternatives([]);
    const alts = await getMealAlternatives(meal);
    setAlternatives(alts);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-10 pb-32">
      <div className="flex bg-slate-950 p-2 rounded-2xl shadow-2xl border border-slate-800 max-w-xl mx-auto">
        <button 
          onClick={() => setActiveView('MEALS')}
          className={`flex-1 py-3 px-6 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeView === 'MEALS' ? 'bg-cyan-600 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
        >
          Nutrition
        </button>
        <button 
          onClick={() => setActiveView('EXERCISE')}
          className={`flex-1 py-3 px-6 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeView === 'EXERCISE' ? 'bg-cyan-600 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
        >
          Protocol
        </button>
        <button 
          onClick={() => setActiveView('ADVICE')}
          className={`flex-1 py-3 px-6 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeView === 'ADVICE' ? 'bg-cyan-600 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
        >
          Coach
        </button>
      </div>

      {activeView === 'MEALS' && (
        <div className="space-y-10 animate-in fade-in duration-700">
          <div className="bg-slate-900/40 p-6 rounded-3xl border border-slate-800 flex items-center justify-between max-w-2xl mx-auto">
            <h4 className="text-sm font-black text-slate-400 uppercase tracking-widest italic">Viewing For:</h4>
            <div className="flex gap-4">
              <button 
                onClick={() => setIsTrainingDay(true)}
                className={`px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition ${isTrainingDay ? 'bg-cyan-600 text-white' : 'bg-slate-800 text-slate-500'}`}
              >
                Gym Day
              </button>
              <button 
                onClick={() => setIsTrainingDay(false)}
                className={`px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition ${!isTrainingDay ? 'bg-slate-100 text-black' : 'bg-slate-800 text-slate-500'}`}
              >
                Rest Day
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {(isTrainingDay ? trainingDayMacros : restDayMacros) && (
              <>
                {[
                  { label: 'Total Calories', val: (isTrainingDay ? trainingDayMacros : restDayMacros)?.calories, unit: 'kcal', color: 'text-cyan-400' },
                  { label: 'Protein (Target)', val: (isTrainingDay ? trainingDayMacros : restDayMacros)?.p, unit: 'g', color: 'text-green-400' },
                  { label: 'Carbs', val: (isTrainingDay ? trainingDayMacros : restDayMacros)?.c, unit: 'g', color: 'text-yellow-400' },
                  { label: 'Fats', val: (isTrainingDay ? trainingDayMacros : restDayMacros)?.f, unit: 'g', color: 'text-red-400' }
                ].map((m, i) => (
                  <div key={i} className="bg-slate-900/60 p-6 md:p-8 rounded-3xl border border-slate-800/60 text-center">
                    <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-2">{m.label}</p>
                    <p className={`text-2xl md:text-3xl font-black ${m.color}`}>{m.val}{m.unit}</p>
                  </div>
                ))}
              </>
            )}
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {mealPlan.map((meal, idx) => (
              <div key={idx} className="bg-slate-900 p-8 md:p-10 rounded-[2.5rem] shadow-xl border border-slate-800 group hover:border-cyan-900/40 transition-all">
                <div className="flex justify-between items-start mb-8">
                  <div>
                    <span className="text-[10px] font-black text-cyan-500 uppercase tracking-[0.3em]">{meal.mealType}</span>
                    <h3 className="text-2xl font-black text-white mt-1 italic leading-tight">{meal.name}</h3>
                  </div>
                  <div className="text-right">
                    <p className="text-xl font-black text-white">{meal.macros.calories}</p>
                    <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest">Kcal</p>
                  </div>
                </div>
                <div className="space-y-8">
                  <div>
                    <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4 border-b border-slate-800 pb-2">Ingredients</h4>
                    <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2">
                      {meal.ingredients.map((ing, i) => (
                        <li key={i} className="text-sm text-slate-300 flex items-start gap-3">
                          <span className="w-1.5 h-1.5 rounded-full bg-cyan-500 mt-1.5 shrink-0" /> 
                          <span className="font-medium">{ing}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* BESPKE SUBSTITUTES ARRAY */}
                  {meal.substitutes && meal.substitutes.length > 0 && (
                     <div className="bg-slate-950/40 p-4 rounded-2xl border border-slate-800/50">
                        <h4 className="text-[8px] font-black text-cyan-500 uppercase tracking-widest mb-2">Bespoke Substitutes</h4>
                        <div className="flex flex-wrap gap-2">
                           {meal.substitutes.map((sub, i) => (
                              <span key={i} className="px-3 py-1 bg-slate-900 text-[10px] text-slate-400 font-bold italic rounded-lg border border-slate-800">{sub}</span>
                           ))}
                        </div>
                     </div>
                  )}
                  
                  {/* SMART SWAP FEATURE */}
                  <div className="relative">
                     <button 
                        onClick={() => handleSmartSwap(meal, idx)}
                        className="w-full py-4 bg-slate-950 border border-slate-800 rounded-2xl flex items-center justify-center gap-3 hover:border-cyan-500 transition-all group/swap"
                     >
                        <span className="text-sm">🔄</span>
                        <span className="text-[10px] font-black text-slate-400 group-hover/swap:text-white uppercase tracking-widest italic">Smart Macro-Swap</span>
                     </button>
                     
                     {swappingMealIdx === idx && (
                        <div className="absolute inset-x-0 bottom-full mb-4 bg-slate-950 p-6 rounded-3xl border border-cyan-500/30 shadow-2xl animate-in zoom-in slide-in-from-bottom-4 z-10 backdrop-blur-xl">
                           <div className="flex justify-between items-center mb-4">
                              <p className="text-[9px] font-black text-cyan-400 uppercase tracking-widest italic">AI Suggested Alternatives</p>
                              <button onClick={() => setSwappingMealIdx(null)} className="text-slate-500 hover:text-white">×</button>
                           </div>
                           {alternatives.length === 0 ? (
                              <div className="flex items-center gap-3 p-4">
                                 <div className="w-4 h-4 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin" />
                                 <p className="text-xs text-slate-500 italic">Calculating macro equivalents...</p>
                              </div>
                           ) : (
                              <div className="space-y-3">
                                 {alternatives.map((alt, i) => (
                                    <div key={i} className="p-3 bg-slate-900/60 rounded-xl border border-slate-800 text-sm text-white font-bold italic">
                                       {alt}
                                    </div>
                                 ))}
                                 <p className="text-[8px] text-slate-600 italic text-center pt-2">Values approximate based on typical portions</p>
                              </div>
                           )}
                        </div>
                     )}
                  </div>

                  <div>
                    <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4 border-b border-slate-800 pb-2">Instructions</h4>
                    <p className="text-sm text-slate-400 leading-relaxed font-medium">{meal.instructions}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeView === 'EXERCISE' && (
        <div className="space-y-8 animate-in fade-in duration-700">
          {workoutSplit.map((day, idx) => (
            <div key={idx} className="bg-slate-900 rounded-[3rem] shadow-2xl border border-slate-800 overflow-hidden">
              <div className="bg-slate-950 px-10 py-8 flex justify-between items-center border-b border-slate-800">
                <div>
                  <p className="text-xs font-black text-cyan-500 uppercase tracking-[0.4em] mb-1">Session {idx + 1}</p>
                  <h3 className="text-3xl font-black text-white italic">{day.title}</h3>
                </div>
                <div className="hidden sm:block px-6 py-2 bg-slate-900 rounded-full text-[10px] font-black text-slate-500 uppercase tracking-widest border border-slate-800">
                  {day.exercises.length} Movements • 60 Mins
                </div>
              </div>
              <div className="p-6 md:p-10">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-separate border-spacing-y-4">
                    <thead>
                      <tr className="text-[10px] font-black text-slate-500 uppercase tracking-widest">
                        <th className="pb-4 px-4">Exercise</th>
                        <th className="pb-4 px-4 text-center">Scheme</th>
                        <th className="pb-4 px-4 text-center">RPE</th>
                        <th className="pb-4 px-4 text-center">Tempo</th>
                        <th className="pb-4 px-4">Demo</th>
                      </tr>
                    </thead>
                    <tbody>
                      {day.exercises.map((ex, i) => (
                        <tr key={i} className="bg-slate-950/40 hover:bg-slate-950 transition-colors group">
                          <td className="py-6 px-4 rounded-l-3xl">
                            <p className="text-lg font-black text-white group-hover:text-cyan-400 transition">{ex.name}</p>
                            <p className="text-[10px] text-slate-500 italic mt-0.5">{ex.notes}</p>
                          </td>
                          <td className="py-6 px-4 text-center">
                            <span className="text-sm font-bold text-slate-300 bg-slate-900 px-3 py-1 rounded-lg border border-slate-800">{ex.sets} × {ex.reps}</span>
                          </td>
                          <td className="py-6 px-4 text-center">
                            <span className="text-xl font-black text-cyan-500 italic">{ex.targetRpe}</span>
                          </td>
                          <td className="py-6 px-4 text-center">
                            <span className="text-xs font-black text-slate-500 tracking-tighter tabular-nums">{ex.tempo}</span>
                          </td>
                          <td className="py-6 px-4 text-center rounded-r-3xl">
                            {ex.videoUrl && (
                              <a href={ex.videoUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-cyan-600 hover:bg-cyan-500 text-white shadow-lg transition">
                                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg>
                              </a>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeView === 'ADVICE' && (
        <div className="animate-in fade-in duration-700 max-w-3xl mx-auto">
          <div className="bg-slate-900 p-8 md:p-12 rounded-[3.5rem] border border-slate-800 shadow-2xl relative overflow-hidden">
             <div className="absolute top-0 right-0 p-10 opacity-10">
                <span className="text-8xl">💡</span>
             </div>
             <div className="relative z-10">
                <h3 className="text-4xl font-black text-white metallic-text uppercase mb-8 italic">Your Success Strategy</h3>
                <div className="prose prose-invert max-w-none">
                   <p className="text-xl text-slate-400 leading-relaxed font-medium">
                     {coachAdvice || "Focus on consistency, water, and hitting your daily step targets."}
                   </p>
                </div>
                <div className="mt-12 grid grid-cols-1 sm:grid-cols-2 gap-6">
                   <div className="p-6 bg-slate-950 rounded-2xl border border-slate-800">
                      <p className="text-[10px] font-black text-cyan-500 uppercase tracking-widest mb-2">Mindset</p>
                      <p className="text-sm text-slate-400 leading-relaxed">Consistency is better than perfection. Aim for 80% adherence every single day.</p>
                   </div>
                   <div className="p-6 bg-slate-950 rounded-2xl border border-slate-800">
                      <p className="text-[10px] font-black text-cyan-500 uppercase tracking-widest mb-2">Recovery</p>
                      <p className="text-sm text-slate-400 leading-relaxed">Sleep is where you lose fat and build muscle. Aim for 7-8 hours of quality rest.</p>
                   </div>
                </div>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PlanDisplay;
