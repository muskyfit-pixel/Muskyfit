
import React, { useState, useEffect, useRef } from 'react';
import { WorkoutDay, WorkoutExercise, ExerciseLog, SetLog } from '../types';

interface WorkoutTrackerProps {
  currentWorkout: WorkoutDay;
  previousProgress: Record<string, number>;
  onFinish: (logs: ExerciseLog[]) => void;
}

const WorkoutTracker: React.FC<WorkoutTrackerProps> = ({ currentWorkout, previousProgress, onFinish }) => {
  const [exerciseLogs, setExerciseLogs] = useState<ExerciseLog[]>(
    currentWorkout.exercises.map(ex => ({
      exerciseId: ex.id,
      sets: Array.from({ length: ex.sets }).map(() => ({
        weight: previousProgress[ex.id] || 0,
        reps: parseInt(ex.reps) || 0,
        rpe: ex.targetRpe,
        completed: false
      }))
    }))
  );

  const [timerActive, setTimerActive] = useState(false);
  const [timeLeft, setTimeLeft] = useState(60);
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    if (timerActive && timeLeft > 0) {
      timerRef.current = window.setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setTimerActive(false);
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [timerActive, timeLeft]);

  const startRestTimer = (seconds: number = 60) => {
    setTimeLeft(seconds);
    setTimerActive(true);
  };

  const updateSet = (exIdx: number, setIdx: number, updates: Partial<SetLog>) => {
    setExerciseLogs(prev => {
      const newLogs = [...prev];
      newLogs[exIdx].sets[setIdx] = { ...newLogs[exIdx].sets[setIdx], ...updates };
      return newLogs;
    });
  };

  const toggleSetCompletion = (exIdx: number, setIdx: number) => {
    const isNowCompleted = !exerciseLogs[exIdx].sets[setIdx].completed;
    updateSet(exIdx, setIdx, { completed: isNowCompleted });
    if (isNowCompleted) {
      const isWarmup = currentWorkout.exercises[exIdx].isWarmup;
      startRestTimer(isWarmup ? 15 : 90); 
    }
  };

  const totalVolume = exerciseLogs.reduce((acc, ex) => 
    acc + ex.sets.reduce((sAcc, s) => sAcc + (s.completed ? s.weight * s.reps : 0), 0), 0
  );

  const completedSets = exerciseLogs.reduce((acc, ex) => acc + ex.sets.filter(s => s.completed).length, 0);
  const totalSets = exerciseLogs.reduce((acc, ex) => acc + ex.sets.length, 0);
  const progressPercent = (completedSets / totalSets) * 100;

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-40 animate-in fade-in duration-700">
      {/* ELITE HUD HEADER */}
      <div className="bg-slate-900 rounded-[2.5rem] p-8 border border-slate-800 shadow-2xl sticky top-20 z-40 backdrop-blur-lg">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-4">
             <div className="w-16 h-16 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-center relative overflow-hidden">
                <div className="absolute inset-0 bg-cyan-500/10 animate-pulse" />
                <span className="text-3xl relative z-10">⚔️</span>
             </div>
             <div>
                <h2 className="text-2xl font-black text-white italic uppercase tracking-tighter metallic-text leading-tight">{currentWorkout.title}</h2>
                <div className="flex items-center gap-3 mt-1">
                   <span className="text-[10px] font-black text-cyan-500 uppercase tracking-widest">{currentWorkout.day}</span>
                   <div className="w-1 h-1 rounded-full bg-slate-700" />
                   <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">60 MIN SESSION</span>
                </div>
             </div>
          </div>
          
          <div className="flex items-center gap-8">
             <div className="text-center">
                <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">Total Tonnage</p>
                <p className="text-2xl font-black text-white tabular-nums">{totalVolume.toLocaleString()}<span className="text-xs text-slate-600 ml-1">kg</span></p>
             </div>
             <div className="w-px h-10 bg-slate-800" />
             <div className="text-center">
                <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">Progress</p>
                <div className="flex items-center gap-3">
                   <div className="w-24 h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                      <div className="h-full bg-cyan-500 shadow-[0_0_10px_rgba(6,182,212,0.5)] transition-all duration-500" style={{ width: `${progressPercent}%` }} />
                   </div>
                   <span className="text-sm font-black text-white">{Math.round(progressPercent)}%</span>
                </div>
             </div>
          </div>
        </div>
      </div>

      {/* EXERCISE LIST */}
      <div className="space-y-10">
        {currentWorkout.exercises.map((ex, exIdx) => {
          const isWarmup = ex.isWarmup;
          return (
            <div key={ex.id} className={`bg-slate-900 rounded-[3rem] border overflow-hidden shadow-xl transition-all ${isWarmup ? 'border-amber-900/40 ring-1 ring-amber-500/10' : 'border-slate-800'}`}>
               {/* Phase Indicator */}
               {isWarmup && (
                  <div className="bg-amber-950/30 px-8 py-2 border-b border-amber-900/20">
                     <p className="text-[8px] font-black text-amber-500 uppercase tracking-[0.4em] italic">Phase 1: 10-Minute Cardio Warm-up</p>
                  </div>
               )}

               {/* Exercise Title Bar */}
               <div className="bg-slate-950 px-8 py-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-800">
                  <div className="flex items-center gap-4">
                     <span className={`w-10 h-10 rounded-xl border flex items-center justify-center font-black italic ${isWarmup ? 'bg-amber-950 text-amber-500 border-amber-800' : 'bg-slate-900 text-cyan-500 border-slate-800'}`}>{exIdx + 1}</span>
                     <div>
                        <h3 className="text-xl font-black text-white italic group-hover:text-cyan-400 transition">{ex.name}</h3>
                        <div className="flex items-center gap-3 mt-0.5">
                           <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">{ex.sets} Sets × {ex.reps}</span>
                           <span className="text-[9px] font-black text-cyan-600 uppercase tracking-widest">Effort: {ex.targetRpe}/10</span>
                        </div>
                     </div>
                  </div>
                  <div className="flex items-center gap-4">
                     {ex.videoUrl && (
                       <a href={ex.videoUrl} target="_blank" rel="noopener noreferrer" className="p-3 bg-slate-900 border border-slate-800 rounded-xl hover:bg-cyan-900/40 hover:border-cyan-500 transition-all flex items-center gap-2 text-[10px] font-black text-slate-400 hover:text-white uppercase tracking-widest">
                          <svg className="w-4 h-4 text-cyan-500" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                          Form Guide
                       </a>
                     )}
                  </div>
               </div>

               {/* Coaching Note */}
               {ex.notes && (
                  <div className={`px-8 py-3 border-b flex items-center gap-3 ${isWarmup ? 'bg-amber-950/10 border-amber-900/10' : 'bg-cyan-950/10 border-slate-800/50'}`}>
                     <span className="text-xs">{isWarmup ? '🏃' : '💡'}</span>
                     <p className="text-[10px] text-slate-400 font-medium italic">Coach Note: {ex.notes}</p>
                  </div>
               )}

               {/* Set Logging Area */}
               <div className="p-8 space-y-4">
                  <div className="grid grid-cols-12 gap-4 px-4 text-[9px] font-black text-slate-600 uppercase tracking-widest">
                     <div className="col-span-1 text-center">Set</div>
                     <div className="col-span-3 text-center">Prev</div>
                     <div className="col-span-3 text-center">{isWarmup ? 'Duration' : 'Weight (kg)'}</div>
                     <div className="col-span-2 text-center">{isWarmup ? 'Incline/Level' : 'Reps'}</div>
                     <div className="col-span-1 text-center">RPE</div>
                     <div className="col-span-2 text-center">Done</div>
                  </div>

                  {exerciseLogs[exIdx].sets.map((set, setIdx) => (
                     <div key={setIdx} className={`grid grid-cols-12 gap-4 items-center p-4 rounded-2xl transition-all border ${set.completed ? 'bg-cyan-950/20 border-cyan-900/30' : 'bg-slate-950 border-slate-800 hover:border-slate-700'}`}>
                        <div className="col-span-1 text-center font-black text-slate-500 text-xs">{setIdx + 1}</div>
                        <div className="col-span-3 text-center">
                           <div className="bg-slate-900 px-3 py-2 rounded-lg text-[10px] font-black text-slate-400">
                             {previousProgress[ex.id] || '--'}
                           </div>
                        </div>
                        <div className="col-span-3">
                           <input type={isWarmup ? "text" : "number"} value={set.weight || ''} disabled={set.completed} onChange={e => updateSet(exIdx, setIdx, { weight: Number(e.target.value) || 0 })} placeholder={isWarmup ? "5:00" : "0"} className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-center text-sm font-black text-white outline-none disabled:opacity-50" />
                        </div>
                        <div className="col-span-2">
                           <input type={isWarmup ? "text" : "number"} value={set.reps || ''} disabled={set.completed} onChange={e => updateSet(exIdx, setIdx, { reps: Number(e.target.value) || 0 })} placeholder={isWarmup ? "Level 10" : "0"} className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-center text-sm font-black text-white outline-none disabled:opacity-50" />
                        </div>
                        <div className="col-span-1">
                           <select value={set.rpe} disabled={set.completed} onChange={e => updateSet(exIdx, setIdx, { rpe: Number(e.target.value) })} className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 text-center text-xs font-black text-cyan-500 outline-none appearance-none disabled:opacity-50">
                              {[1,2,3,4,5,6,7,8,9,10].map(v => <option key={v} value={v}>{v}</option>)}
                           </select>
                        </div>
                        <div className="col-span-2 flex justify-center">
                           <button onClick={() => toggleSetCompletion(exIdx, setIdx)} className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${set.completed ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-900/50' : 'bg-slate-900 border border-slate-800 text-slate-700 hover:text-white hover:border-slate-500'}`}>
                             {set.completed ? <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"/></svg> : <div className="w-4 h-4 border-2 border-current rounded" />}
                           </button>
                        </div>
                     </div>
                  ))}
               </div>
            </div>
          );
        })}
      </div>

      {/* FLOATING REST TIMER */}
      {timerActive && (
        <div className="fixed bottom-32 left-1/2 -translate-x-1/2 z-50 animate-in slide-in-from-bottom-10 duration-500">
           <div className="bg-white px-8 py-4 rounded-full shadow-[0_20px_50px_rgba(0,0,0,0.5)] flex items-center gap-6 border-4 border-cyan-500">
              <div className="flex flex-col">
                 <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest leading-none mb-1">Recovery...</p>
                 <p className="text-3xl font-black text-black tabular-nums leading-none">
                    {Math.floor(timeLeft / 60)}:{String(timeLeft % 60).padStart(2, '0')}
                 </p>
              </div>
              <button onClick={() => setTimerActive(false)} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200 transition">
                 <svg className="w-6 h-6 text-black" fill="currentColor" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>
              </button>
           </div>
        </div>
      )}

      {/* FINISH WORKOUT BUTTON */}
      <div className="fixed bottom-10 left-1/2 -translate-x-1/2 z-50 w-full max-w-sm px-6">
        <button onClick={() => onFinish(exerciseLogs)} className="w-full py-6 bg-white text-black font-black uppercase tracking-[0.3em] rounded-2xl shadow-[0_20px_40px_rgba(0,0,0,0.4)] hover:bg-cyan-500 hover:text-white transition-all transform hover:scale-[1.02] active:scale-95 italic border-4 border-slate-900">
          Complete 60-Min Protocol
        </button>
      </div>
    </div>
  );
};

export default WorkoutTracker;
