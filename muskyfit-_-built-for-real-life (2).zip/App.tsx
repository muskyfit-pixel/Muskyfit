
import React, { useState, useEffect } from 'react';
import Navigation from './components/Navigation';
import IntakeForm from './components/IntakeForm';
import PlanDisplay from './components/PlanDisplay';
import CoachDashboard from './components/CoachDashboard';
import DailyLogging from './components/DailyLogging';
import WorkoutTracker from './components/WorkoutTracker';
import WeeklyCheckInForm from './components/WeeklyCheckInForm';
import ClientProgressSummary from './components/ClientProgressSummary';
import { generatePersonalizedPlan } from './services/geminiService';
import { MOCK_CLIENTS } from './constants';
import { Client, IntakeData, ExerciseLog, DailyLog, WeeklyCheckIn } from './types';

const App = () => {
  const [role, setRole] = useState<'COACH' | 'CLIENT'>('CLIENT');
  const [activeTab, setActiveTab] = useState('client-dashboard');
  
  // Persistence logic
  const [clients, setClients] = useState<Client[]>(() => {
    const saved = localStorage.getItem('muskyfit_clients');
    try {
      return saved ? JSON.parse(saved) : MOCK_CLIENTS;
    } catch (e) {
      return MOCK_CLIENTS;
    }
  });
  
  const [currentClientId, setCurrentClientId] = useState<string | null>(() => {
    const saved = localStorage.getItem('muskyfit_active_client');
    if (saved) return saved;
    // Safely check if MOCK_CLIENTS has items before accessing index 0
    return MOCK_CLIENTS.length > 0 ? MOCK_CLIENTS[0].id : null;
  });

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    localStorage.setItem('muskyfit_clients', JSON.stringify(clients));
  }, [clients]);

  useEffect(() => {
    if (currentClientId) {
      localStorage.setItem('muskyfit_active_client', currentClientId);
    }
  }, [currentClientId]);

  const currentClient = clients.find(c => c.id === currentClientId) || null;

  useEffect(() => {
    setActiveTab(role === 'COACH' ? 'coach-dashboard' : 'client-dashboard');
  }, [role]);

  const handleIntakeSubmit = async (data: IntakeData) => {
    setIsLoading(true);
    const newId = 'client_' + Date.now();
    const newClient: Client = {
      id: newId,
      profile: { id: 'user_' + newId, name: data.name, email: data.email, phone: data.phone, role: 'CLIENT', avatar: `https://api.dicebear.com/7.x/initials/svg?seed=${data.name}` },
      intake: data,
      planStatus: 'CONSULTATION_SUBMITTED',
      currentWorkoutIndex: 0,
      exerciseProgress: {},
      logs: [],
      checkIns: [],
      performanceStatus: 'ON_TRACK'
    };
    setClients(prev => [...prev, newClient]);
    setCurrentClientId(newId);
    setIsLoading(false);
    setActiveTab('client-dashboard');
  };

  const handleCoachFinalise = async (clientId: string, overrides: Partial<IntakeData>) => {
    setIsLoading(true);
    setError(null);
    try {
      const targetClient = clients.find(c => c.id === clientId);
      if (targetClient && targetClient.intake) {
        const updatedIntake = { ...targetClient.intake, ...overrides };
        const plan = await generatePersonalizedPlan(updatedIntake);
        setClients(prev => prev.map(c => c.id === clientId ? { ...c, intake: updatedIntake, plan, planStatus: 'PLAN_READY', currentWorkoutIndex: 0 } : c));
      }
    } catch (err) {
      setError("Failed to build bespoke plan. Check AI connection.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogSave = (log: DailyLog) => {
    setClients(prev => prev.map(c => c.id === currentClientId ? { ...c, logs: [log, ...c.logs] } : c));
    setActiveTab('client-dashboard');
  };

  const handleCheckInSubmit = (checkIn: WeeklyCheckIn) => {
    setClients(prev => prev.map(c => c.id === currentClientId ? { ...c, checkIns: [checkIn, ...(c.checkIns || [])] } : c));
    setActiveTab('client-dashboard');
  };

  const handleWorkoutFinish = (exerciseLogs: ExerciseLog[]) => {
    if (!currentClient || !currentClient.plan) return;
    const workoutCount = currentClient.plan.workoutSplit.length;
    const nextIndex = (currentClient.currentWorkoutIndex + 1) % workoutCount;
    const newProgress = { ...currentClient.exerciseProgress };
    exerciseLogs.forEach(log => {
      const maxWeight = Math.max(...log.sets.map(s => s.weight), 0);
      if (maxWeight > 0) newProgress[log.exerciseId] = maxWeight;
    });
    const newLog: DailyLog = {
      date: new Date().toISOString().split('T')[0],
      steps: 0, water: 0, caloriesConsumed: 0, proteinConsumed: 0, carbsConsumed: 0, fatsConsumed: 0,
      workoutCompleted: true, exerciseLogs, workoutId: currentClient.plan.workoutSplit[currentClient.currentWorkoutIndex].id
    };
    setClients(prev => prev.map(c => c.id === currentClientId ? { ...c, currentWorkoutIndex: nextIndex, exerciseProgress: newProgress, logs: [newLog, ...c.logs] } : c));
    setActiveTab('client-dashboard');
  };

  const getClientTrafficLight = (client: Client) => {
    if (!client.logs || client.logs.length === 0) return { color: 'bg-slate-700', label: 'Awaiting Data' };
    const lastLog = client.logs[0];
    const targetCals = client.plan?.trainingDayMacros?.calories || 2500;
    const variance = Math.abs((lastLog.caloriesConsumed - targetCals) / targetCals);
    if (variance <= 0.08 && (lastLog.steps >= 8000 || lastLog.workoutCompleted)) return { color: 'bg-green-500', label: 'Elite Adherence' };
    if (variance <= 0.20) return { color: 'bg-amber-500', label: 'Fair Effort' };
    return { color: 'bg-red-500', label: 'Action Required' };
  };

  const renderContent = () => {
    if (role === 'COACH') {
      const pending = clients.find(c => c.planStatus === 'CONSULTATION_SUBMITTED') || null;
      return <CoachDashboard clients={clients.filter(c => c.planStatus === 'PLAN_READY')} pendingClient={pending} onFinalise={handleCoachFinalise} isLoading={isLoading} />;
    }
    
    // If no client exists or plan is not ready, show the intake form
    if (!currentClient || currentClient.planStatus === 'NONE') {
      return (
        <div className="py-10">
          <IntakeForm onSubmit={handleIntakeSubmit} isLoading={isLoading} />
        </div>
      );
    }

    if (currentClient.planStatus === 'CONSULTATION_SUBMITTED') {
      return (
        <div className="max-w-3xl mx-auto text-center py-24">
          <div className="mb-10 inline-flex items-center justify-center w-28 h-28 rounded-full bg-slate-900 border-4 border-cyan-500 cyan-glow"><span className="text-5xl">🧬</span></div>
          <h2 className="text-5xl font-black text-white mb-6 uppercase tracking-tighter italic">Building Protocol</h2>
          <p className="text-xl text-slate-400 leading-relaxed max-w-xl mx-auto mb-10">Analysis of your biomechanical and lifestyle profile is underway.</p>
        </div>
      );
    }

    if (activeTab === 'client-dashboard') {
      const status = getClientTrafficLight(currentClient);
      const latestReport = currentClient.checkIns?.[0]?.coachFeedback;

      return (
        <div className="space-y-10 pb-20 animate-in fade-in duration-700 px-4 sm:px-0">
          <div className="bg-gradient-to-br from-slate-900 to-slate-950 p-10 md:p-12 rounded-[3.5rem] border border-slate-800 relative overflow-hidden">
             <div className="relative z-10">
                <div className="flex justify-between items-start">
                  <div>
                    <h2 className="text-4xl md:text-5xl font-black text-white metallic-text uppercase mb-3 leading-tight">Elite Hub</h2>
                    <p className="text-cyan-500 font-bold uppercase tracking-[0.4em] text-[10px] md:text-xs">Performance Optimization</p>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <div className={`w-4 h-4 rounded-full ${status.color} cyan-glow animate-pulse`} />
                    <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">{status.label}</span>
                  </div>
                </div>
                
                <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8">
                   <div className="p-6 md:p-8 bg-slate-950/50 rounded-3xl border border-slate-800/50 backdrop-blur-sm">
                      <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-3">Weight</p>
                      <p className="text-2xl md:text-3xl font-black text-white">{currentClient.intake?.weight}<span className="text-xs ml-1 text-slate-600">kg</span></p>
                   </div>
                   <div className="p-6 md:p-8 bg-slate-950/50 rounded-3xl border border-slate-800/50 backdrop-blur-sm">
                      <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-3">Goal</p>
                      <p className="text-sm font-black text-cyan-500 uppercase leading-tight">{currentClient.intake?.goal?.replace('_', ' ')}</p>
                   </div>
                   <div className="p-6 md:p-8 bg-slate-950/50 rounded-3xl border border-slate-800/50 backdrop-blur-sm">
                      <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-3">Cycle</p>
                      <p className="text-2xl font-black text-white italic">#1</p>
                   </div>
                   <div className="p-6 md:p-8 bg-slate-950/50 rounded-3xl border border-slate-800/50 backdrop-blur-sm">
                      <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-3">Status</p>
                      <p className="text-sm font-black text-green-500 uppercase leading-tight">ON TRACK</p>
                   </div>
                </div>
             </div>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
              <div className="grid md:grid-cols-3 gap-6">
                <button onClick={() => setActiveTab('workout')} className="p-8 bg-white rounded-[2.5rem] text-left hover:scale-[1.02] transition-all shadow-2xl group">
                   <span className="text-4xl block mb-6 group-hover:rotate-12 transition">🏋️</span>
                   <h3 className="text-2xl font-black text-black uppercase tracking-tighter italic leading-none">Train</h3>
                   <p className="text-slate-500 text-[10px] mt-3 font-bold uppercase tracking-wider">Start bespoke session</p>
                </button>
                <button onClick={() => setActiveTab('log')} className="p-8 bg-cyan-600 rounded-[2.5rem] text-left hover:scale-[1.02] transition-all shadow-2xl group">
                   <span className="text-4xl block mb-6 group-hover:scale-110 transition">🥗</span>
                   <h3 className="text-2xl font-black text-white uppercase tracking-tighter italic leading-none">Macros</h3>
                   <p className="text-cyan-100 text-[10px] mt-3 font-bold uppercase tracking-wider">Fuel your evolution</p>
                </button>
                <button onClick={() => setActiveTab('checkin')} className="p-8 bg-slate-900 border border-slate-800 rounded-[2.5rem] text-left hover:scale-[1.02] transition-all shadow-2xl group">
                   <span className="text-4xl block mb-6 group-hover:-translate-y-1 transition">📅</span>
                   <h3 className="text-2xl font-black text-white uppercase tracking-tighter italic leading-none">Check-In</h3>
                   <p className="text-slate-500 text-[10px] mt-3 font-bold uppercase tracking-wider">Weekly Reflection</p>
                </button>
              </div>

              <ClientProgressSummary logs={currentClient.logs} />
            </div>

            <div className="space-y-6">
               <div className="bg-slate-900 rounded-[3rem] p-10 border border-slate-800 shadow-2xl">
                  <h4 className="text-[10px] font-black text-cyan-500 uppercase tracking-widest mb-6 italic">Coach's Intel</h4>
                  {latestReport ? (
                    <div className="prose prose-invert prose-sm">
                      <p className="text-slate-300 italic text-sm leading-relaxed">{latestReport}</p>
                    </div>
                  ) : (
                    <p className="text-slate-500 italic text-xs leading-relaxed">Submit your weekly check-in to receive professional feedback and block adjustments from your MuskyFit coach.</p>
                  )}
               </div>
               
               <button onClick={() => setActiveTab('plans')} className="w-full py-6 bg-slate-950 border border-slate-800 rounded-3xl text-[10px] font-black text-slate-400 uppercase tracking-widest hover:border-cyan-500 transition-all italic">
                  Full Strategy Protocol
               </button>
            </div>
          </div>
        </div>
      );
    }
    if (activeTab === 'log') return <DailyLogging onSave={handleLogSave} targetMacros={currentClient?.plan?.trainingDayMacros} />;
    if (activeTab === 'checkin') return <WeeklyCheckInForm onSubmit={handleCheckInSubmit} />;
    if (activeTab === 'workout') return <WorkoutTracker currentWorkout={currentClient.plan!.workoutSplit[currentClient.currentWorkoutIndex]} previousProgress={currentClient.exerciseProgress} onFinish={handleWorkoutFinish} />;
    if (activeTab === 'plans') return <PlanDisplay mealPlan={currentClient.plan?.mealPlan || []} workoutSplit={currentClient.plan?.workoutSplit || []} trainingDayMacros={currentClient.plan?.trainingDayMacros} restDayMacros={currentClient.plan?.restDayMacros} coachAdvice={currentClient.plan?.coachAdvice} />;
    return null;
  };

  return (
    <div className="min-h-screen bg-[#070b14] selection:bg-cyan-500 selection:text-white">
      <Navigation role={role} setRole={setRole} activeTab={activeTab} setActiveTab={setActiveTab} />
      <main className="max-w-7xl mx-auto pt-6 md:pt-12">{renderContent()}</main>
    </div>
  );
};

export default App;
